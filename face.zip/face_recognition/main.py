from PyQt5.Qt import *
import sys
import dataRecord
import dataManage
import core
import logging.config

app = QApplication(sys.argv)

# 使用位于'./config/logging.cfg'的配置文件配置日志/Configure logging using the configuration file located at './config/logging.cfg'
logging.config.fileConfig('./config/logging.cfg')

mainWidget = QTabWidget()

# 创建不同模块中定义的UI类的实例/Create instances of UI classes defined in different modules
window1 = core.CoreUI()  # 从core模块导入的CoreUI
window2 = dataRecord.DataRecordUI()  # 从dataRecord模块导入的DataRecordUI
window3 = dataManage.DataManageUI()  # 从dataManage模块导入的DataManageUI

# 设置主窗口的大小/size
mainWidget.resize(1020, 600)

# 设置窗口标题/title
mainWidget.setWindowTitle("Face_recognition")

# 设置窗口图标/icon
mainWidget.setWindowIcon(QIcon('./icons/icon.png'))

# 将标签添加到主窗口，并将每个标签与其相应的窗口关联/# Add tabs to the main window and associate each tab with its corresponding window
mainWidget.addTab(window1, "Face Recognition")  # "人脸识别"标签/"Face Recognition" tag
mainWidget.addTab(window2, "Add People")  # "新增人员"标签/"Add People" tag
mainWidget.addTab(window3, "Model Training")  # "模型训练"标签/"Model Training" tag

mainWidget.show()

sys.exit(app.exec())
